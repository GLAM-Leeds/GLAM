################# Script to define model parameters
# GLAM-Parti parameters
kfac = 0.7 # Light extinction coefficient
SLA = 180  # Specific leaf area (cm2 g-1)

#### Subset within-season crop data table only for treatments in training period 
Allometry_train_period <- subset(Within_season_crop_data, Treatments %in% Training_treat)

# Calculate mass of leaves and chaffs for allometric relationship
Allometry_train_period$Phot_mass <- rowSums(Allometry_train_period[,c("ML_season", "MEAR_season")], na.rm=TRUE)
Allometry_train_period$Phot_mass[Allometry_train_period$Phot_mass == 0] <- NA 

# Change units from t/ha to g/m2
Allometry_train_period$Phot_mass <- Allometry_train_period$Phot_mass*100
Allometry_train_period$MS_season <- Allometry_train_period$MS_season*100

#### Extract slope and intercept from linear regression between log(MS) vs. log(MP) 
h <- exp(as.numeric(coef(lm(log(Allometry_train_period$MS_season) ~ log(Allometry_train_period$Phot_mass)))[1]))
g <- as.numeric(coef(lm(log(Allometry_train_period$MS_season) ~ log(Allometry_train_period$Phot_mass)))[2])

