###### Script to run GLAM-Parti for all crop treatments

# Select every new treatment and run the model to make prediction 
for (irun in 1:length(All_treat)){
  itreat_run <- All_treat[irun]
  
  # Subset treatment 
  Crop_dates_treatment <- subset(End_of_season_crop_data, End_of_season_crop_data$Treatment==itreat_run)
  
  # Day of emergence of treatment
  DOE <- Crop_dates_treatment$Emergence + Crop_dates_treatment$Planting_year*1000
  
  # Import correct weather file per treatment 
  if (str_sub(itreat_run,-1,-1)=='C'){
    Input_weather_file <- read.table('./Input_data/Weather_data/AZ000306.wth', header = T)

  }else if (str_sub(itreat_run,-1,-1)=='H'){
    if (itreat_run=='1H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ110306.wth', header = T)
    }else if (itreat_run=='7H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ310306.wth', header = T)
    }else if (itreat_run=='9H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ440306.wth', header = T)
    }else if (itreat_run=='14H'){
      Input_weather_file <- read.table('./Input_data/Weather_data/AZ610306.wth', header = T)
    }
  }
  
  # Correct the date column and set it as integer
  Input_weather_file$X.DATE <-Input_weather_file$X.DATE + 2000000
  Input_weather_file$X.DATE <- as.integer(Input_weather_file$X.DATE)
  
  ### Subset weather variables to start at crop emergence of specific treatment 
  Input_weather_for_treat <- subset(Input_weather_file, Input_weather_file$X.DATE >= DOE)
  
  # If weather file contains multiple years, subset only weather variables of one year starting at crop emergence
  if (nrow(Input_weather_for_treat) > 366){Input_weather_for_treat <- Input_weather_for_treat[1:366,]}
  Input_weather_for_treat$Day <- c(1:nrow(Input_weather_for_treat))
  
  # Call GLAM-Parti to make predictions
  source("./GLAM_Parti_model.R")
  
    # Save model output to folder
  Daily_model_output <- rbind(Daily_model_output, data.frame(itreat_run, c(1:length(W_vec)), MP_vec, MS_vec, W_vec, YIELD_vec, HI_vec, RUE_vec, no_experiments_training, irep, paste(Training_treat, collapse = ","), ML_model))
  
  End_of_season_model_output <- rbind(End_of_season_model_output, data.frame(itreat_run, tail(MP_vec, 1), tail(MS_vec, 1), tail(W_vec, 1), tail(YIELD_vec, 1), 
                                                                 tail(HI_vec, 1), tail(RUE_vec, 1), Anthesis_day, Maturity_day, no_experiments_training, irep, paste(Training_treat, collapse = ","), ML_model))
}
